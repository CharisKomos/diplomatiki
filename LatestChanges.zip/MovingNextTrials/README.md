# Crude biogas separation with membrane modules

This is a project for my bachelor's thesis which aims to treat crude biogas and produce high purity CH4 and CO2 for the industry.
